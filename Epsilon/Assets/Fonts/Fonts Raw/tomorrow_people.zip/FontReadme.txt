Tomorrow People Theme
=====================

This file contains a TrueType font based on the original Tomorrow 
People series.

The icons and cursors were developed on a Windows NT 4.0 system, but
should be compatible with Windows 95 and Windows 3.1x.


Files
-----

This ZIP file contains the following file.

     Tomoprg_.ttf


Installation
------------

Unzip the file into the Windows Font folder.  The font will be
available in the normal Font dialog boxes.





Original Work Copyright (C) 1998 D.A.Johnson   davej@easynet.co.uk

